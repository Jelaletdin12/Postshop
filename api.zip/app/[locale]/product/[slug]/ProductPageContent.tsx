"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Minus, Plus, Heart, ShoppingCart, Store } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import placeholder from "@/public/jb.webp"

// Types
interface ProductLabel {
  text: string
  bg_color: string
}

interface Property {
  name: string
  value: string
}

interface VariantValue {
  id: number
  name: string
  value: string
  is_selected: boolean
}

interface Variant {
  type: "IMAGE" | "TEXT"
  name: string
  values: VariantValue[]
}

interface Product {
  id: number
  name: string
  description: string
  brand: string | null
  model: string | null
  images: string[]
  labels: ProductLabel[]
  properties: Property[]
  struct_price_text: string
  struct_price: string
  price_color: string
  is_favorite: boolean
}

interface Seller {
  id: number
  name: string
}

interface ProductDetailProps {
  product: Product
  variants?: Variant[]
  seller: Seller
  otherProducts?: Product[]
  cartQuantity?: number
  locale?: string
  translations?: {
    addToCart: string
    goToCart: string
    price: string
    aboutProduct: string
    brand: string
    model: string
    description: string
    recommended: string
    store: string
    writeToStore: string
    color: string
  }
  slug: string // Added slug prop
}

// Mock fetch functions for demonstration
async function fetchProduct(slug: string): Promise<Product> {
  // Simulate fetching product data
  console.log(`Fetching product for slug: ${slug}`)
  return {
    id: 1,
    name: "Stylish T-Shirt",
    description: "A comfortable and stylish t-shirt made from premium cotton. Perfect for everyday wear.",
    brand: "FashionBrand",
    model: "TS-001",
    images: ["/product1.webp", "/product1_back.webp"],
    labels: [{ text: "New Arrival", bg_color: "#4CAF50" }],
    properties: [
      { name: "Material", value: "100% Cotton" },
      { name: "Fit", value: "Regular" },
    ],
    struct_price_text: "$29.99",
    struct_price: "29.99",
    price_color: "#000000",
    is_favorite: false,
  }
}

async function fetchProductVariants(productId: number): Promise<Variant[]> {
  // Simulate fetching variant data
  console.log(`Fetching variants for product ID: ${productId}`)
  return [
    {
      type: "IMAGE",
      name: "Color",
      values: [
        { id: 1, name: "Red", value: "/red_variant.webp", is_selected: true },
        { id: 2, name: "Blue", value: "/blue_variant.webp", is_selected: false },
      ],
    },
    {
      type: "TEXT",
      name: "Size",
      values: [
        { id: 3, name: "S", value: "S", is_selected: false },
        { id: 4, name: "M", value: "M", is_selected: true },
        { id: 5, name: "L", value: "L", is_selected: false },
      ],
    },
  ]
}

async function fetchSeller(productId: number): Promise<Seller> {
  // Simulate fetching seller data
  console.log(`Fetching seller for product ID: ${productId}`)
  return { id: 101, name: "Awesome Seller" }
}

async function fetchOtherProducts(productId: number): Promise<Product[]> {
  // Simulate fetching other products
  console.log(`Fetching other products for product ID: ${productId}`)
  return [
    {
      id: 2,
      name: "Cool Jeans",
      description: "Durable denim jeans.",
      brand: "DenimCo",
      model: "DJ-200",
      images: ["/product2.webp"],
      labels: [],
      properties: [],
      struct_price_text: "$49.99",
      struct_price: "49.99",
      price_color: "#000000",
      is_favorite: false,
    },
    {
      id: 3,
      name: "Casual Hoodie",
      description: "A warm and cozy hoodie.",
      brand: "ComfortWear",
      model: "CH-300",
      images: ["/product3.webp"],
      labels: [{ text: "Sale", bg_color: "#FF9800" }],
      properties: [],
      struct_price_text: "$39.99",
      struct_price: "39.99",
      price_color: "#000000",
      is_favorite: false,
    },
  ]
}

const ProductPageContent = ({ slug }: { slug: string }) => {
  const [isClient, setIsClient] = useState(false)
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [isFavorite, setIsFavorite] = useState(false)
  const [isInCart, setIsInCart] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const [product, setProduct] = useState<Product | null>(null)
  const [variants, setVariants] = useState<Variant[]>([])
  const [seller, setSeller] = useState<Seller | null>(null)
  const [otherProducts, setOtherProducts] = useState<Product[]>([])

  const t = {
    addToCart: "Add to Cart",
    goToCart: "Go to Cart",
    price: "Price:",
    aboutProduct: "About Product",
    brand: "Brand",
    model: "Model",
    description: "Product Description",
    recommended: "Recommended Products",
    store: "Store",
    writeToStore: "Write to Store",
    color: "Color:",
  }

  useEffect(() => {
    setIsClient(true)
    // Fetch product data when the component mounts
    const fetchData = async () => {
      try {
        const fetchedProduct = await fetchProduct(slug)
        setProduct(fetchedProduct)
        setQuantity(fetchedProduct.is_favorite ? 1 : 1) // Initialize quantity
        setIsFavorite(fetchedProduct.is_favorite)
        setIsInCart(fetchedProduct.is_favorite) // Assume favorite means in cart for this mock

        const fetchedVariants = await fetchProductVariants(fetchedProduct.id)
        setVariants(fetchedVariants)

        const fetchedSeller = await fetchSeller(fetchedProduct.id)
        setSeller(fetchedSeller)

        const fetchedOtherProducts = await fetchOtherProducts(fetchedProduct.id)
        setOtherProducts(fetchedOtherProducts)
      } catch (error) {
        console.error("Error fetching product data:", error)
        // Handle error appropriately, maybe redirect to notFound()
      }
    }
    fetchData()
  }, [slug])

  const handleAddToCart = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))
    setIsInCart(true)
    setIsLoading(false)
  }

  const handleQuantityChange = async (newQuantity: number) => {
    if (newQuantity < 1) return
    setIsLoading(true)
    setQuantity(newQuantity)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 300))
    setIsLoading(false)
  }

  const handleToggleFavorite = () => {
    setIsFavorite(!isFavorite)
    // Implement favorite toggle logic
  }

  const handleVariantChange = (variantId: number) => {
    // Navigate to new product variant - simplified for example
    // In a real app, this might involve fetching data for the new variant
    // or navigating to a new URL.
    console.log(`Changing to variant ID: ${variantId}`)
    // For demonstration, let's just log and potentially update state if needed
    // For actual navigation, you'd use Next.js router or window.location.href
    // window.location.href = `/product/${variantId}`;
  }

  if (!isClient || !product) return null // Render null until client-side and data is fetched

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Product Images */}
        <div className="flex-1 max-w-2xl">
          <div className="relative">
            {/* Main Image */}
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-gray-50">
              {product.labels && product.labels.length > 0 && (
                <div className="absolute top-0 right-0 z-10 flex flex-col gap-1">
                  {product.labels.map((label) => (
                    <Badge
                      key={label.text}
                      className="rounded-l-md rounded-r-none text-white text-xs font-bold uppercase"
                      style={{ backgroundColor: label.bg_color }}
                    >
                      {label.text}
                    </Badge>
                  ))}
                </div>
              )}
              <Image
                src={product.images?.[selectedImage] ?? placeholder}
                alt={product.name}
                fill
                className="object-contain"
                priority
              />
            </div>

            {/* Thumbnail Images */}
            {product?.images?.length > 1 && (
              <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`relative w-16 h-16 rounded overflow-hidden border ${
                      selectedImage === index ? "border-black" : "border-transparent"
                    }`}
                  >
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} thumbnail ${index + 1}`}
                      fill
                      className="object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Product Info */}
        <div className="flex-1 space-y-6">
          {/* Title & Properties */}
          <div>
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            {product.properties && product.properties.length > 0 && (
              <div className="flex gap-2 flex-wrap">
                {product.properties.map((prop) => (
                  <span key={prop.value} className="text-sm text-gray-500">
                    {prop.name}: {prop.value}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Variants */}
          {variants.map((variant) => (
            <div key={variant.type}>
              {variant.type === "IMAGE" ? (
                <div>
                  <p className="text-sm mb-3">
                    <span className="text-gray-500">{t.color}</span> {product.name}
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    {variant.values.map((value) => (
                      <button
                        key={value.id}
                        onClick={() => handleVariantChange(value.id)}
                        className={`relative w-14 h-18 rounded-lg border-2 p-1 transition-all hover:border-primary ${
                          value.is_selected ? "border-primary" : "border-gray-200"
                        }`}
                      >
                        <Image
                          src={value.value || "/placeholder.svg"}
                          alt={value.name}
                          fill
                          className="object-cover rounded-md"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div>
                  <p className="text-sm text-gray-500 mb-2">{variant.name}</p>
                  <Select
                    defaultValue={variant.values.find((v) => v.is_selected)?.id.toString()}
                    onValueChange={(value) => handleVariantChange(Number(value))}
                  >
                    <SelectTrigger className="w-full max-w-md rounded-xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {variant.values.map((value) => (
                        <SelectItem key={value.id} value={value.id.toString()}>
                          {value.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          ))}

          {/* Product Info Table */}
          <Card className="p-4 rounded-xl">
            <h3 className="text-xl font-semibold mb-4">{t.aboutProduct}</h3>
            <div className="space-y-3">
              {product.brand && (
                <>
                  <div className="flex justify-between items-center py-2">
                    <span className="text-gray-500">{t.brand}</span>
                    <span className="font-medium">{product.brand}</span>
                  </div>
                  <Separator />
                </>
              )}
              {product.model && (
                <>
                  <div className="flex justify-between items-center py-2">
                    <span className="text-gray-500">{t.model}</span>
                    <span className="font-medium">{product.model}</span>
                  </div>
                  <Separator />
                </>
              )}
            </div>
          </Card>

          {/* Description */}
          {product.description && (
            <div>
              <h3 className="text-xl font-semibold mb-3">{t.description}</h3>
              <p className="text-gray-700 leading-relaxed">{product.description}</p>
            </div>
          )}
        </div>

        {/* Price & Actions Sidebar */}
        <div className="lg:w-[420px] space-y-4">
          {/* Price Card */}
          <Card className="p-6 rounded-xl shadow-lg">
            <div className="flex justify-between items-center mb-6">
              <span className="text-lg text-gray-500">{t.price}</span>
              <span className="text-3xl font-bold">{product.struct_price_text}</span>
            </div>

            <div className="space-y-4">
              {/* Cart Actions */}
              {isInCart ? (
                <div className="space-y-3">
                  <Link href="/cart/summary">
                    <Button size="lg" className="w-full rounded-xl text-lg font-bold bg-green-600 hover:bg-green-700">
                      <ShoppingCart className="mr-2 h-5 w-5" />
                      {t.goToCart}
                    </Button>
                  </Link>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleQuantityChange(quantity - 1)}
                      disabled={quantity === 1 || isLoading}
                      className="rounded-xl bg-blue-50 flex-shrink-0"
                    >
                      <Minus className="h-5 w-5" />
                    </Button>
                    <div className="flex-1 text-center font-semibold text-lg">{quantity}</div>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleQuantityChange(quantity + 1)}
                      disabled={isLoading}
                      className="rounded-xl bg-blue-50 flex-shrink-0"
                    >
                      <Plus className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  size="lg"
                  onClick={handleAddToCart}
                  disabled={isLoading}
                  className="w-full rounded-xl text-lg font-bold"
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  {t.addToCart}
                </Button>
              )}

              {/* Favorite Button */}
              <Button
                variant="outline"
                size="lg"
                onClick={handleToggleFavorite}
                className={`w-full rounded-xl ${
                  isFavorite ? "bg-red-50 border-red-200 hover:bg-red-100" : "bg-blue-50"
                }`}
              >
                <Heart className={`h-6 w-6 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
              </Button>
            </div>
          </Card>

          {/* Seller Card */}
          <Card className="p-6 rounded-xl">
            <div className="flex items-center gap-4 mb-4">
              <Avatar className="w-14 h-14">
                <AvatarFallback>
                  <Store className="h-6 w-6" />
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm text-gray-500">{t.store}</p>
                <h4 className="text-xl font-bold hover:text-primary cursor-pointer">{seller?.name}</h4>
              </div>
            </div>
            <Button variant="outline" size="lg" disabled className="w-full rounded-xl bg-transparent">
              {t.writeToStore}
            </Button>
          </Card>
        </div>
      </div>

      {/* Recommended Products */}
      {otherProducts && otherProducts.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">{t.recommended}</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {otherProducts.slice(0, 5).map((item) => (
              <Link key={item.id} href={`/product/${item.id}`}>
                <Card className="group cursor-pointer overflow-hidden rounded-xl hover:shadow-lg transition-shadow">
                  <div className="relative aspect-square">
                    <Image
                      src={item.images[0] || "/placeholder.svg"}
                      alt={item.name}
                      fill
                      className="object-contain p-4 group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <div className="p-3">
                    <h3 className="font-medium text-sm line-clamp-2 mb-2">{item.name}</h3>
                    <p className="text-lg font-bold text-primary">{item.struct_price_text}</p>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default ProductPageContent
