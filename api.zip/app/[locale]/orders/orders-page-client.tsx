"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

// Types
interface OrderItem {
  product: {
    id: number
    name: string
    image: string
  }
}

interface BillingItem {
  title: string
  value: string
}

interface Order {
  id: number
  status: "PENDING" | "PROCESSING" | "DELIVERED" | "CANCELLED"
  status_trans: string
  items: OrderItem[]
  billing: {
    body: BillingItem[]
  }
}

interface OrdersData {
  active_orders: Order[]
  complete_orders: Order[]
}

interface OrdersPageProps {
  locale?: string
}

export default function OrdersPageClient({ locale }: OrdersPageProps) {
  // Dummy data for demonstration
  const [ordersData, setOrdersData] = useState<OrdersData>({
    active_orders: [
      {
        id: 1,
        status: "PROCESSING",
        status_trans: "Processing",
        items: [{ product: { id: 1, name: "T-Shirt", image: "/images/tshirt.png" } }],
        billing: { body: [{ title: "Total", value: "$25.00" }] },
      },
    ],
    complete_orders: [
      {
        id: 2,
        status: "DELIVERED",
        status_trans: "Delivered",
        items: [{ product: { id: 2, name: "Jeans", image: "/images/jeans.png" } }],
        billing: { body: [{ title: "Total", value: "$50.00" }] },
      },
      {
        id: 3,
        status: "CANCELLED",
        status_trans: "Cancelled",
        items: [{ product: { id: 3, name: "Shoes", image: "/images/shoes.png" } }],
        billing: { body: [{ title: "Total", value: "$75.00" }] },
      },
    ],
  })

  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false)
  const [orderToCancel, setOrderToCancel] = useState<Order | null>(null)

  const handleCancelOrder = (order: Order) => {
    setOrderToCancel(order)
    setIsCancelDialogOpen(true)
  }

  const confirmCancelOrder = () => {
    if (orderToCancel) {
      // In a real app, you would make an API call here to cancel the order
      console.log(`Cancelling order: ${orderToCancel.id}`)
      // Update state to remove the order or change its status
      setOrdersData((prev) => ({
        ...prev,
        active_orders: prev.active_orders.filter((o) => o.id !== orderToCancel.id),
        complete_orders: prev.complete_orders.map((o) =>
          o.id === orderToCancel.id ? { ...o, status: "CANCELLED", status_trans: "Cancelled" } : o,
        ),
      }))
      setIsCancelDialogOpen(false)
      setOrderToCancel(null)
    }
  }

  const getStatusBadge = (status: Order["status"]) => {
    switch (status) {
      case "PENDING":
        return <Badge variant="outline">{status}</Badge>
      case "PROCESSING":
        return <Badge variant="secondary">{status}</Badge>
      case "DELIVERED":
        return <Badge variant="success">{status}</Badge>
      case "CANCELLED":
        return <Badge variant="destructive">{status}</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">My Orders</h1>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="active">Active Orders</TabsTrigger>
          <TabsTrigger value="completed">Completed Orders</TabsTrigger>
        </TabsList>

        <TabsContent value="active">
          {ordersData.active_orders.length === 0 ? (
            <p>You have no active orders.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {ordersData.active_orders.map((order) => (
                <Card key={order.id} className="p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="text-lg font-semibold">Order #{order.id}</h3>
                      {getStatusBadge(order.status)}
                    </div>
                    <div className="flex items-center mb-3">
                      {order.items.map((item) => (
                        <Image
                          key={item.product.id}
                          src={item.product.image || "/placeholder.svg"}
                          alt={item.product.name}
                          width={50}
                          height={50}
                          className="mr-3 rounded"
                        />
                      ))}
                      <div className="flex-1">
                        {order.items.map((item) => (
                          <p key={item.product.id} className="text-sm text-muted-foreground">
                            {item.product.name}
                          </p>
                        ))}
                      </div>
                    </div>
                    {order.billing.body.map((billingItem) => (
                      <div key={billingItem.title} className="flex justify-between text-sm">
                        <span>{billingItem.title}</span>
                        <span>{billingItem.value}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4">
                    <Button variant="destructive" onClick={() => handleCancelOrder(order)}>
                      Cancel Order
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed">
          {ordersData.complete_orders.length === 0 ? (
            <p>You have no completed orders.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {ordersData.complete_orders.map((order) => (
                <Card key={order.id} className="p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="text-lg font-semibold">Order #{order.id}</h3>
                      {getStatusBadge(order.status)}
                    </div>
                    <div className="flex items-center mb-3">
                      {order.items.map((item) => (
                        <Image
                          key={item.product.id}
                          src={item.product.image || "/placeholder.svg"}
                          alt={item.product.name}
                          width={50}
                          height={50}
                          className="mr-3 rounded"
                        />
                      ))}
                      <div className="flex-1">
                        {order.items.map((item) => (
                          <p key={item.product.id} className="text-sm text-muted-foreground">
                            {item.product.name}
                          </p>
                        ))}
                      </div>
                    </div>
                    {order.billing.body.map((billingItem) => (
                      <div key={billingItem.title} className="flex justify-between text-sm">
                        <span>{billingItem.title}</span>
                        <span>{billingItem.value}</span>
                      </div>
                    ))}
                  </div>
                  {order.status === "CANCELLED" && (
                    <div className="mt-4">
                      <Button variant="outline" disabled>
                        Order Cancelled
                      </Button>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Are you sure you want to cancel this order?</DialogTitle>
            <DialogDescription>This action cannot be undone.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCancelDialogOpen(false)}>
              No
            </Button>
            <Button variant="destructive" onClick={confirmCancelOrder}>
              Yes, Cancel Order
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
