"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useSearchParams } from "next/navigation"
import { ChevronLeft, SlidersHorizontal, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { ScrollArea } from "@/components/ui/scroll-area"
import CategoryPageContent from "./CategoryContent"
import { notFound } from "next/navigation"
// No metadata here as it's handled by the server component

// Types
interface FilterItem {
  key: string
  value: number
  name: string
  hex?: string
  image?: string
  selected?: boolean
  slug?: string
  children?: FilterItem[]
}

interface Filter {
  uuid: string
  title: string
  type: "TREE" | "SELECTABLE" | "VOLUME" | "TAB" | "COLOR"
  items: FilterItem | FilterItem[]
}

interface ProductFiltersProps {
  filters: Filter[]
  locale?: string
  translations?: {
    filter: string
    from: string
    to: string
    reset: string
  }
}

export default function CategoryPageClient({ params }: { params: { locale: string; slug: string } }) {
  const { slug } = params
  const searchParams = useSearchParams()

  const [isOpen, setIsOpen] = useState(false)
  // Dummy translations for demonstration, replace with actual i18n
  const t = {
    filter: "Filters",
    from: "From",
    to: "To",
    reset: "Reset",
  }

  if (!slug) {
    notFound()
  }

  // Placeholder for fetching filter data and other page content
  const filters: Filter[] = [
    {
      uuid: "1",
      title: "Category",
      type: "TREE",
      items: {
        key: "category",
        value: 1,
        name: "All",
        slug: slug,
        selected: true,
        children: [
          { key: "category", value: 2, name: "Electronics", slug: "electronics", selected: false },
          { key: "category", value: 3, name: "Clothing", slug: "clothing", selected: false },
        ],
      },
    },
    {
      uuid: "2",
      title: "Brand",
      type: "SELECTABLE",
      items: [
        { key: "brand", value: 10, name: "Brand A", image: "/brand-a.png", selected: false },
        { key: "brand", value: 11, name: "Brand B", image: "/brand-b.png", selected: false },
      ],
    },
    {
      uuid: "3",
      title: "Price",
      type: "VOLUME",
      items: {} as FilterItem, // This type is just for demonstration, actual data structure might differ
    },
    {
      uuid: "4",
      title: "Color",
      type: "COLOR",
      items: [
        { key: "color", value: 100, name: "Red", hex: "#FF0000", selected: false },
        { key: "color", value: 101, name: "Blue", hex: "#0000FF", selected: false },
      ],
    },
    {
      uuid: "5",
      title: "Tags",
      type: "TAB",
      items: [
        { key: "tag", value: 200, name: "New Arrival", selected: false },
        { key: "tag", value: 201, name: "Sale", selected: false },
      ],
    },
  ]

  const handleFilterChange = (key: string, value: number | number[]) => {
    console.log(`Filter changed: ${key} with value ${value}`)
    // Implement logic to update filters and re-fetch data
  }

  const handlePriceInputChange = (type: "from" | "to", value: string) => {
    console.log(`Price input changed: ${type} with value ${value}`)
    // Implement logic to update price range input
  }

  const FiltersContent = () => (
    <div className="space-y-6">
      {filters.map((filter) => {
        switch (filter.type) {
          case "TREE":
            return (
              <CategoryFilter
                key={filter.uuid}
                data={filter.items as FilterItem} // Assuming 'items' is a single FilterItem for TREE type
                title={filter.title}
              />
            )
          case "SELECTABLE":
            return (
              <BrandFilter
                key={filter.uuid}
                data={filter.items as FilterItem[]}
                title={filter.title}
                onFilterChange={handleFilterChange}
              />
            )
          case "VOLUME":
            // Price filter needs specific state for priceRange and potentially input values
            const priceRange: [number, number] = [100, 500] // Dummy data
            return (
              <PriceFilter
                key={filter.uuid}
                title={filter.title}
                priceRange={priceRange}
                onPriceChange={handleFilterChange}
                onInputChange={handlePriceInputChange}
                translations={{ from: t.from, to: t.to }}
              />
            )
          case "COLOR":
            return (
              <ColorFilter
                key={filter.uuid}
                data={filter.items as FilterItem[]}
                title={filter.title}
                onFilterChange={handleFilterChange}
              />
            )
          case "TAB":
            return (
              <TagFilter
                key={filter.uuid}
                data={filter.items as FilterItem[]}
                title={filter.title}
                onFilterChange={handleFilterChange}
              />
            )
          default:
            return null
        }
      })}
      <Button
        variant="outline"
        className="w-full rounded-xl bg-transparent"
        onClick={() => console.log("Reset filters")}
      >
        {t.reset}
      </Button>
    </div>
  )

  return (
    <>
      <CategoryPageContent slug={slug} />
      {/* Mobile Filter Button */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button className="sm:hidden fixed bottom-4 right-4 rounded-xl font-bold gap-2 z-10" size="lg">
            {t.filter}
            <SlidersHorizontal className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[290px] p-0">
          <SheetHeader className="p-4 border-b">
            <SheetTitle>{t.filter}</SheetTitle>
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-4 right-4 rounded-md ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary data-[state=closed]:bg-primary hover:bg-secondary h-4 w-4"
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </button>
          </SheetHeader>
          <ScrollArea className="h-[calc(100vh-80px)] p-4">
            <FiltersContent />
          </ScrollArea>
        </SheetContent>
      </Sheet>

      {/* Desktop Filters */}
      <div className="hidden sm:block w-[280px] flex-shrink-0 border-r pr-4">
        <ScrollArea className="h-[calc(100vh-120px)]">
          <FiltersContent />
        </ScrollArea>
      </div>
    </>
  )
}

// Category Filter Component
function CategoryFilter({ data, title }: { data: FilterItem; title: string }) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="space-y-1">
        <Link
          href={`/category/${data.slug}?category_id=${data.value}`}
          className={`flex items-center gap-2 py-2 px-2 rounded-lg hover:bg-gray-100 transition-colors ${
            data.selected ? "text-primary font-medium" : ""
          }`}
        >
          <ChevronLeft className="h-4 w-4" />
          {data.name}
        </Link>
        {data.children && data.children.length > 0 && (
          <div className="ml-6 space-y-1">
            {data.children.map((child) => (
              <Link
                key={child.value}
                href={`/category/${child.slug}?category_id=${child.value}`}
                className={`block py-2 px-2 rounded-lg hover:bg-gray-100 transition-colors ${
                  child.selected ? "text-primary font-medium" : ""
                }`}
              >
                {child.name}
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// Brand Filter Component
function BrandFilter({
  data,
  title,
  onFilterChange,
}: {
  data: FilterItem[]
  title: string
  onFilterChange: (key: string, value: number) => void
}) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <ScrollArea className="max-h-[410px]">
        <div className="space-y-1">
          {data.map((item) => (
            <button
              key={item.value}
              onClick={() => onFilterChange(item.key, item.value)}
              className={`w-full flex items-center gap-3 py-2 px-2 rounded-lg hover:bg-gray-100 transition-colors group ${
                item.selected ? "text-primary" : ""
              }`}
            >
              {item.image && (
                <div
                  className={`flex items-center justify-center w-[50px] h-[50px] bg-gray-50 rounded-lg border-2 transition-colors ${
                    item.selected ? "border-primary" : "border-transparent group-hover:border-primary"
                  }`}
                >
                  <div className="relative w-8 h-8">
                    <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-contain" />
                  </div>
                </div>
              )}
              <span className="text-left">{item.name}</span>
            </button>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

// Price Filter Component
function PriceFilter({
  title,
  priceRange,
  onPriceChange,
  onInputChange,
  translations,
}: {
  title: string
  priceRange: [number, number]
  onPriceChange: (values: number[]) => void
  onInputChange: (type: "from" | "to", value: string) => void
  translations: { from: string; to: string }
}) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="space-y-4">
        <div className="flex gap-2">
          <div className="flex-1">
            <Label htmlFor="price-from" className="text-xs mb-1">
              {translations.from}
            </Label>
            <Input
              id="price-from"
              type="number"
              value={priceRange[0]}
              onChange={(e) => onInputChange("from", e.target.value)}
              className="rounded-lg"
            />
          </div>
          <div className="flex-1">
            <Label htmlFor="price-to" className="text-xs mb-1">
              {translations.to}
            </Label>
            <Input
              id="price-to"
              type="number"
              value={priceRange[1]}
              onChange={(e) => onInputChange("to", e.target.value)}
              className="rounded-lg"
            />
          </div>
        </div>
        <Slider min={0} max={99999} step={100} value={priceRange} onValueChange={onPriceChange} className="mt-2" />
      </div>
    </div>
  )
}

// Tag Filter Component
function TagFilter({
  data,
  title,
  onFilterChange,
}: {
  data: FilterItem[]
  title: string
  onFilterChange: (key: string, value: number) => void
}) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="space-y-2">
        {data.map((item) => (
          <div key={item.value} className="flex items-center space-x-2">
            <Checkbox
              id={`tag-${item.value}`}
              checked={item.selected}
              onCheckedChange={() => onFilterChange(item.key, item.value)}
            />
            <Label htmlFor={`tag-${item.value}`} className="text-sm font-normal cursor-pointer">
              {item.name}
            </Label>
          </div>
        ))}
      </div>
    </div>
  )
}

// Color Filter Component
function ColorFilter({
  data,
  title,
  onFilterChange,
}: {
  data: FilterItem[]
  title: string
  onFilterChange: (key: string, value: number) => void
}) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="grid grid-cols-5 gap-2">
        {data.map((item) => (
          <button
            key={item.value}
            onClick={() => onFilterChange(item.key, item.value)}
            className={`w-[36px] h-[36px] rounded-lg border-2 p-1 transition-all hover:scale-110 ${
              item.selected ? "border-primary shadow-md" : "border-gray-200"
            }`}
            title={item.name}
          >
            <div className="w-full h-full rounded-md border-2 border-gray-200" style={{ backgroundColor: item.hex }} />
          </button>
        ))}
      </div>
    </div>
  )
}
