import React from "react";
import { MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import PaymentTypeSelector from "./PaymentTypeSelector";
import DeliveryTypeSelector from "./DeliveryTypeSelector";
import {
  Order,
  Region,
  PickUpPoint,
  PaymentType,
  DeliveryType,
  CartTranslations,
} from "./types";

interface OrderSummaryProps {
  order: Order;
  translations: CartTranslations;
  paymentType: PaymentType;
  deliveryType: DeliveryType;
  selectedRegion: number;
  selectedAddress: string;
  note: string;
  regions: Region[];
  addresses: string[];
  pickupPoints: PickUpPoint[];
  onPaymentTypeChange: (type: PaymentType) => void;
  onDeliveryTypeChange: (type: DeliveryType) => void;
  onRegionChange: (regionId: number) => void;
  onAddressChange: (address: string) => void;
  onNoteChange: (note: string) => void;
  onMapOpen: () => void;
  onCompleteOrder: () => void;
}

export default function OrderSummary({
  order,
  translations: t,
  paymentType,
  deliveryType,
  selectedRegion,
  selectedAddress,
  note,
  regions,
  addresses,
  pickupPoints,
  onPaymentTypeChange,
  onDeliveryTypeChange,
  onRegionChange,
  onAddressChange,
  onNoteChange,
  onMapOpen,
  onCompleteOrder,
}: OrderSummaryProps) {
  const addressOptions =
    deliveryType === "SELECTED_DELIVERY"
      ? addresses
      : pickupPoints.map((p) => p.name);

  return (
    <Card className="w-full md:w-[380px] p-6 rounded-xl h-fit sticky top-20">
      {/* Payment Type */}
      <PaymentTypeSelector
        selectedType={paymentType}
        onSelect={onPaymentTypeChange}
        translations={t}
      />

      {/* Delivery Type */}
      <DeliveryTypeSelector
        selectedType={deliveryType}
        onSelect={onDeliveryTypeChange}
        translations={t}
      />

      {/* Region Selection */}
      <div className="mb-6">
        <Label className="text-lg font-semibold mb-3 block">
          {t.selectRegion}
        </Label>
        <RadioGroup
          value={selectedRegion.toString()}
          onValueChange={(value) => onRegionChange(Number(value))}
          className="flex flex-wrap gap-4"
        >
          {regions.map((region) => (
            <div key={region.id} className="flex items-center space-x-2">
              <RadioGroupItem
                value={region.id.toString()}
                id={`region-${region.id}`}
                className="border-2 border-gray-400 data-[state=checked]:border-[#005bff] data-[state=checked]:bg-white data-[state=checked]:[&_svg]:fill-[#005bff] data-[state=checked]:[&_svg]:stroke-[#005bff]"
              />
              <Label
                htmlFor={`region-${region.id}`}
                className="cursor-pointer"
              >
                {region.name}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      {/* Address Selection */}
      <div className="mb-6">
        <Label className="text-lg font-semibold mb-3 block">
          {t.selectAddress}
        </Label>
        <div className="flex gap-2">
          <Select value={selectedAddress} onValueChange={onAddressChange}>
            <SelectTrigger className="rounded-xl">
              <SelectValue placeholder={t.selectAddress} />
            </SelectTrigger>
            <SelectContent>
              {addressOptions.map((addr, index) => (
                <SelectItem key={index} value={addr}>
                  {addr}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="icon"
            onClick={onMapOpen}
            className="rounded-xl flex-shrink-0"
          >
            <MapPin className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Note */}
      <div className="mb-6">
        <Label className="text-lg font-semibold mb-3 block">{t.note}</Label>
        <Textarea
          value={note}
          onChange={(e) => onNoteChange(e.target.value)}
          className="rounded-xl resize-none"
          rows={3}
        />
      </div>

      {/* Billing Summary */}
      <div className="space-y-2 mb-4">
        {order.billing.body.map((item, index) => (
          <div key={index} className="flex justify-between text-base font-medium">
            <span>{item.title}:</span>
            <span>{item.value}</span>
          </div>
        ))}
      </div>

      <Separator className="my-4" />

      {/* Total */}
      <div className="flex justify-between items-center mb-6">
        <span className="text-lg font-semibold">
          {order.billing.footer.title}:
        </span>
        <span className="text-lg font-bold text-green-600">
          {order.billing.footer.value}
        </span>
      </div>

      {/* Complete Order Button */}
      <Button
        onClick={onCompleteOrder}
        disabled={!selectedAddress}
        className="w-full rounded-xl bg-[#005bff] hover:bg-[#005bff] cursor-pointer h-12 text-lg font-bold"
        size="lg"
      >
        {t.placeOrder}
      </Button>
    </Card>
  );
}