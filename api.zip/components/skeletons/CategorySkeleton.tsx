import { Skeleton } from "@/components/ui/skeleton"
import { Card } from "@/components/ui/card"
import { CardContent } from "@/components/ui/card"

export default function CategorySkeleton() {
  return (
    <Card className="overflow-hidden rounded-xl">
      {/* Image */}
      <Skeleton className="w-full h-36 bg-gray-200" />

      {/* Name */}
      <CardContent className="py-2">
        <Skeleton className="h-4 w-3/4 bg-gray-200" />
      </CardContent>
    </Card>
  )
}
