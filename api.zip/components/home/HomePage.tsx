"use client"
import { useEffect, useState } from "react"
import { useLocale, useTranslations } from "next-intl"
import HeroCarousel from "./Carousel"
import CategoryGrid from "./CategoryGrid"
import ProductGrid from "./ProductGrid"
import { carouselItems, categories, products } from "./mockData"

export default function HomePage() {
  const locale = useLocale()
  const t = useTranslations("common")
  const [mounted, setMounted] = useState(false)

  useEffect(() => setMounted(true), [])

  if (!mounted) return <div className="p-8">Loading...</div>

  return (
    <div className="px-4 md:px-8 lg:px-12 pt-8 pb-12 space-y-8">
      <HeroCarousel items={carouselItems} />
      <CategoryGrid categories={categories} locale={locale} title={t("categories")} />
      <ProductGrid products={products} title={t("products")} />
    </div>
  )
}