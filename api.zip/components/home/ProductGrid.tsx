"use client"
import ProductCard from "@/components/ProductCard"
import type { StaticImageData } from "next/image"

type Product = {
  id: number
  name: string
  struct_price_text: string
  price: number | null
  images: (StaticImageData | string)[]
  is_favorite: boolean
  labels?: { text: string; bg_color: string }[]
  price_color?: string
}

export default function ProductGrid({ products, title }: { products: Product[]; title: string }) {
  return (
    <section className="bg-white rounded-2xl shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">{title}</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            id={product.id}
            name={product.name}
            price={product.price}
            struct_price_text={product.struct_price_text}
            images={product.images}
            is_favorite={product.is_favorite}
            labels={product.labels}
            price_color={product.price_color ?? "#111"}
            height={360}
            width={250}
            button={true}
          />
        ))}
      </div>
    </section>
  )
}