"use client"
import Image, { type StaticImageData } from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

type Category = {
  id: number
  slug: string
  name: string
  image: StaticImageData | string
}

type Props = {
  categories: Category[]
  locale: string
  title: string
}

export default function CategoryGrid({ categories, locale, title }: Props) {
  return (
    <section className="bg-white rounded-2xl shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">{title}</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {categories.map((cat) => (
          <Link 
            key={cat.id} 
            href={`/${locale}/category/${cat.slug}?category_id=${cat.id}`}
          >
            <Card className="hover:shadow-md border-none shadow-none p-0 gap-2 transition-all cursor-pointer">
              <div className="relative w-full h-36 overflow-hidden">
                <Image 
                  src={cat.image} 
                  alt={cat.name} 
                  fill 
                  className="object-contain"
                />
              </div>
              <CardContent className="py-2">
                <p className="text-sm font-medium text-gray-800 truncate text-center">
                  {cat.name}
                </p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  )
}