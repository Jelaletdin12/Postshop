import React, { useState } from "react";
import Link from "next/link";

interface Category {
  id: number;
  name: string;
  slug: string;
  icon_class?: string;
  children?: Category[];
}

interface CategoryMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const CATEGORIES: Category[] = [
  {
    id: 1,
    name: "Электроника",
    slug: "electronics",
    icon_class: "bx bx-laptop",
    children: [
      { id: 11, name: "Смартфоны", slug: "smartphones" },
      { id: 12, name: "Ноутбуки", slug: "laptops" },
      { id: 13, name: "Планшеты", slug: "tablets" },
    ],
  },
  {
    id: 2,
    name: "Одежда",
    slug: "clothing",
    icon_class: "bx bx-closet",
    children: [
      { id: 21, name: "Мужская одежда", slug: "mens-clothing" },
      { id: 22, name: "Женская одежда", slug: "womens-clothing" },
    ],
  },
  {
    id: 3,
    name: "Дом и сад",
    slug: "home-garden",
    icon_class: "bx bx-home",
    children: [
      { id: 31, name: "Мебель", slug: "furniture" },
      { id: 32, name: "Декор", slug: "decor" },
    ],
  },
];

export default function CategoryMenu({ isOpen, onClose }: CategoryMenuProps) {
  const [hoveredCategory, setHoveredCategory] = useState<number | null>(null);

  if (!isOpen) return null;

  const activeCategory = hoveredCategory !== null ? CATEGORIES[hoveredCategory] : null;

  return (
    <div className="fixed left-0 right-0 top-22 z-40 bg-white border-b shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex">
          <CategoryList
            categories={CATEGORIES}
            onCategoryHover={setHoveredCategory}
            onCategoryClick={onClose}
          />
          
          {activeCategory?.children && (
            <SubcategoryList
              category={activeCategory}
              onSubcategoryClick={onClose}
            />
          )}
        </div>
      </div>
    </div>
  );
}

interface CategoryListProps {
  categories: Category[];
  onCategoryHover: (index: number) => void;
  onCategoryClick: () => void;
}

function CategoryList({ categories, onCategoryHover, onCategoryClick }: CategoryListProps) {
  return (
    <div className="w-[280px] border-r">
      <div className="max-h-[calc(100vh-4rem)] overflow-y-auto py-2">
        {categories.map((category, index) => (
          <Link
            key={category.id}
            href={`/category/${category.slug}?category_id=${category.id}`}
            onClick={onCategoryClick}
            onMouseEnter={() => onCategoryHover(index)}
            className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-gray-100 hover:text-primary transition-colors"
          >
            {category.icon_class && (
              <i className={`${category.icon_class} text-xl`}></i>
            )}
            <span>{category.name}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}

interface SubcategoryListProps {
  category: Category;
  onSubcategoryClick: () => void;
}

function SubcategoryList({ category, onSubcategoryClick }: SubcategoryListProps) {
  return (
    <div className="flex-1 p-6">
      <h3 className="text-xl font-semibold mb-4">{category.name}</h3>
      <div className="grid grid-cols-3 gap-4">
        {category.children?.map((subCategory) => (
          <Link
            key={subCategory.id}
            href={`/category/${subCategory.slug}?category_id=${subCategory.id}`}
            onClick={onSubcategoryClick}
            className="text-gray-600 hover:text-black text-sm py-1 hover:underline"
          >
            {subCategory.name}
          </Link>
        ))}
      </div>
    </div>
  );
}