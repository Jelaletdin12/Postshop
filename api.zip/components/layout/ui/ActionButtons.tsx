import React from "react";
import Link from "next/link";
import { User, Truck, Heart, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface ActionButtonsProps {
  isAuthenticated: boolean;
  onAuthClick: () => void;
  translations: {
    profile: string;
    login: string;
    orders: string;
    favorites: string;
    cart: string;
  };
}

interface ActionButtonData {
  icon: React.ReactNode;
  label: string;
  href?: string;
  onClick?: () => void;
  badgeCount?: number;
}

export default function ActionButtons({
  isAuthenticated,
  onAuthClick,
  translations: t,
}: ActionButtonsProps) {
  const buttons: ActionButtonData[] = [
    {
      icon: <User className="h-5 w-5 text-gray-600" />,
      label: isAuthenticated ? t.profile : t.login,
      onClick: onAuthClick,
    },
    {
      icon: <Truck className="h-5 w-5 text-gray-600" />,
      label: t.orders,
      href: "/orders",
      badgeCount: 0,
    },
    {
      icon: <Heart className="h-5 w-5 text-gray-600" />,
      label: t.favorites,
      href: "/favorites",
      badgeCount: 0,
    },
    {
      icon: <ShoppingCart className="h-5 w-5 text-gray-600" />,
      label: t.cart,
      href: "/cart",
      badgeCount: 0,
    },
  ];

  return (
    <div className="hidden items-center gap-1 md:flex">
      {buttons.map((button, index) => (
        <ActionButton key={index} {...button} />
      ))}
    </div>
  );
}

function ActionButton({
  icon,
  label,
  href,
  onClick,
  badgeCount,
}: ActionButtonData) {
  const buttonContent = (
    <Button
      variant="ghost"
      size="sm"
      className="relative flex-col gap-0.5 h-auto px-2 py-2"
      onClick={onClick}
    >
      <div className="relative">
        {icon}
        {badgeCount !== undefined && (
          <Badge
            variant="destructive"
            className="absolute -right-2 -top-2 h-4 w-4 flex items-center justify-center p-0 text-[10px]"
          >
            {badgeCount}
          </Badge>
        )}
      </div>
      <span className="text-xs text-gray-700">{label}</span>
    </Button>
  );

  if (href) {
    return <Link href={href}>{buttonContent}</Link>;
  }

  return buttonContent;
}