import axios, { type AxiosInstance, type AxiosRequestConfig, type AxiosResponse } from "axios"

/**
 * Centralized API client for all backend requests
 * Handles authentication headers, error handling, and request/response interceptors
 */
class APIClient {
  private client: AxiosInstance
  private baseUrl: string

  constructor() {
    this.baseUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000/api"

    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 10000,
      headers: {
        "Content-Type": "application/json",
      },
    })

    // Request interceptor for adding auth headers
    this.client.interceptors.request.use(
      (config) => {
        // Add auth token if available
        const token = typeof window !== "undefined" ? localStorage.getItem("authToken") : null
        if (token) {
          config.headers.Authorization = `Bearer ${token}`
        }
        return config
      },
      (error) => {
        return Promise.reject(error)
      },
    )

    // Response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        // Handle 401 - redirect to login
        if (error.response?.status === 401) {
          if (typeof window !== "undefined") {
            localStorage.removeItem("authToken")
            window.location.href = "/login"
          }
        }

        return Promise.reject(error)
      },
    )
  }

  get<T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.get<T>(url, config)
  }

  post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.post<T>(url, data, config)
  }

  put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.put<T>(url, data, config)
  }

  patch<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.patch<T>(url, data, config)
  }

  delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.delete<T>(url, config)
  }

  setAuthToken(token: string): void {
    if (typeof window !== "undefined") {
      localStorage.setItem("authToken", token)
    }
    this.client.defaults.headers.common["Authorization"] = `Bearer ${token}`
  }

  clearAuthToken(): void {
    if (typeof window !== "undefined") {
      localStorage.removeItem("authToken")
    }
    delete this.client.defaults.headers.common["Authorization"]
  }
}

// Export singleton instance
export const apiClient = new APIClient()
