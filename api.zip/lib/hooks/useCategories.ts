import { useQuery } from "@tanstack/react-query"
import { apiClient } from "@/lib/api"

export interface Category {
  id: number
  name: string
  slug: string
  image: string
}

export function useCategories(options?: { enabled?: boolean }) {
  return useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await apiClient.get("/categories")
      return response.data as Category[]
    },
    enabled: options?.enabled !== false,
    staleTime: 1000 * 60 * 30, // Cache for 30 minutes
  })
}

export function useCategory(slug: string, options?: { enabled?: boolean }) {
  return useQuery({
    queryKey: ["category", slug],
    queryFn: async () => {
      const response = await apiClient.get(`/categories/${slug}`)
      return response.data as Category
    },
    enabled: options?.enabled !== false && !!slug,
  })
}
