import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { apiClient } from "@/lib/api"

export interface FavoriteItem {
  id: number
  productId: number
  addedAt: string
}

export function useFavorites() {
  return useQuery({
    queryKey: ["favorites"],
    queryFn: async () => {
      const response = await apiClient.get("/favorites")
      return response.data as FavoriteItem[]
    },
    staleTime: 1000 * 60 * 5,
  })
}

export function useAddToFavorites() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (productId: number) => {
      const response = await apiClient.post("/favorites", { productId })
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["favorites"] })
    },
  })
}

export function useRemoveFromFavorites() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (productId: number) => {
      await apiClient.delete(`/favorites/${productId}`)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["favorites"] })
    },
  })
}
