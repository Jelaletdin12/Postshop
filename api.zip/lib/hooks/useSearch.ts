import { useQuery } from "@tanstack/react-query"
import { apiClient } from "@/lib/api"
import type { Product } from "./useProducts"

interface SearchOptions {
  query: string
  category?: string
  priceFrom?: number
  priceTo?: number
  page?: number
  limit?: number
}

export function useSearch(options: SearchOptions) {
  const { query, category, priceFrom, priceTo, page = 1, limit = 20 } = options

  return useQuery({
    queryKey: ["search", { query, category, priceFrom, priceTo, page, limit }],
    queryFn: async () => {
      const params = new URLSearchParams({
        q: query,
        ...(category && { category }),
        ...(priceFrom && { priceFrom: String(priceFrom) }),
        ...(priceTo && { priceTo: String(priceTo) }),
        page: String(page),
        limit: String(limit),
      })

      const response = await apiClient.get(`/search?${params}`)
      return response.data as { products: Product[]; total: number }
    },
    enabled: !!query && query.length > 0,
    staleTime: 1000 * 60 * 5,
  })
}
