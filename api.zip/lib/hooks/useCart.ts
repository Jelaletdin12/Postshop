import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { apiClient } from "@/lib/api"

export interface CartItem {
  id: number
  productId: number
  quantity: number
  price: number
}

export interface Cart {
  id: string
  items: CartItem[]
  total: number
}

export function useCart() {
  return useQuery({
    queryKey: ["cart"],
    queryFn: async () => {
      const response = await apiClient.get("/cart")
      return response.data as Cart
    },
    staleTime: 0, // Always fetch fresh
  })
}

export function useAddToCart() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async ({
      productId,
      quantity = 1,
    }: {
      productId: number
      quantity?: number
    }) => {
      const response = await apiClient.post("/cart/items", {
        productId,
        quantity,
      })
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cart"] })
    },
  })
}

export function useRemoveFromCart() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (itemId: number) => {
      await apiClient.delete(`/cart/items/${itemId}`)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cart"] })
    },
  })
}

export function useUpdateCartItemQuantity() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async ({
      itemId,
      quantity,
    }: {
      itemId: number
      quantity: number
    }) => {
      const response = await apiClient.patch(`/cart/items/${itemId}`, {
        quantity,
      })
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cart"] })
    },
  })
}
