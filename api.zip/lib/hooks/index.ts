// Export all custom hooks for easier imports
export * from "./useProducts"
export * from "./useCategories"
export * from "./useCart"
export * from "./useFavorites"
export * from "./useOrders"
export * from "./useSearch"
