import { useQuery } from "@tanstack/react-query"
import { apiClient } from "@/lib/api"

export interface Product {
  id: number
  name: string
  price: number
  image: string
  category: string
}

interface UseProductsOptions {
  enabled?: boolean
  staleTime?: number
}

export function useProducts(options?: UseProductsOptions) {
  return useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      const response = await apiClient.get("/products")
      return response.data as Product[]
    },
    staleTime: options?.staleTime,
    enabled: options?.enabled !== false,
  })
}

export function useProduct(id: number, options?: UseProductsOptions) {
  return useQuery({
    queryKey: ["product", id],
    queryFn: async () => {
      const response = await apiClient.get(`/products/${id}`)
      return response.data as Product
    },
    staleTime: options?.staleTime,
    enabled: options?.enabled !== false && !!id,
  })
}
