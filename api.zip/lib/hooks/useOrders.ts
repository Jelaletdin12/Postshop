import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { apiClient } from "@/lib/api"

export interface Order {
  id: number
  status: "draft" | "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  total: number
  createdAt: string
}

export function useOrders() {
  return useQuery({
    queryKey: ["orders"],
    queryFn: async () => {
      const response = await apiClient.get("/orders")
      return response.data as Order[]
    },
    staleTime: 1000 * 60 * 5,
  })
}

export function useOrder(id: number) {
  return useQuery({
    queryKey: ["order", id],
    queryFn: async () => {
      const response = await apiClient.get(`/orders/${id}`)
      return response.data as Order
    },
    enabled: !!id,
  })
}

export function useCancelOrder() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (orderId: number) => {
      await apiClient.post(`/orders/${orderId}/cancel`)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["orders"] })
    },
  })
}
