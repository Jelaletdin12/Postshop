/**
 * Development API client with mock adapter
 * Use this instead of lib/api.ts when NEXT_PUBLIC_USE_MOCK_API=true
 */

import axios, { type AxiosInstance, type AxiosRequestConfig, type AxiosResponse } from "axios"
import { createMockAdapter } from "./mock-server/axios-adapter"

class MockAPIClient {
  private client: AxiosInstance
  private baseUrl: string

  constructor() {
    this.baseUrl = "http://localhost:3000/api"

    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 10000,
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (process.env.NEXT_PUBLIC_USE_MOCK_API === "true") {
      this.client.defaults.adapter = createMockAdapter()
    }
  }

  get<T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.get<T>(url, config)
  }

  post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.post<T>(url, data, config)
  }

  put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.put<T>(url, data, config)
  }

  patch<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.patch<T>(url, data, config)
  }

  delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.client.delete<T>(url, config)
  }

  setAuthToken(token: string): void {
    if (typeof window !== "undefined") {
      localStorage.setItem("authToken", token)
    }
    this.client.defaults.headers.common["Authorization"] = `Bearer ${token}`
  }

  clearAuthToken(): void {
    if (typeof window !== "undefined") {
      localStorage.removeItem("authToken")
    }
    delete this.client.defaults.headers.common["Authorization"]
  }
}

export const apiClient = new MockAPIClient()
