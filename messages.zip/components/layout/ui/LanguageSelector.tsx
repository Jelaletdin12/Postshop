import React from "react";
import Link from "next/link";
import Image from "next/image";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import tm from "@/public/tm.png";
import ru from "@/public/ru.png";

interface Language {
  code: string;
  name: string;
  flag: any;
}

interface LanguageSelectorProps {
  locale: string;
}

const LANGUAGES: Language[] = [
  { code: "ru", name: "Russian", flag: ru },
  { code: "tm", name: "Turkmen", flag: tm },
];

export default function LanguageSelector({ locale }: LanguageSelectorProps) {
  return (
    <Select defaultValue={locale}>
      <SelectTrigger className="w-[70px] rounded-xl border-gray-300">
        <SelectValue>
          <FlagIcon locale={locale} />
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        {LANGUAGES.map((language) => (
          <SelectItem key={language.code} value={language.code}>
            <Link
              href="/"
              locale={language.code}
              className="flex items-center gap-2"
            >
              <FlagIcon locale={language.code} />
            </Link>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function FlagIcon({ locale }: { locale: string }) {
  const language = LANGUAGES.find((lang) => lang.code === locale);
  
  if (!language) return null;

  return (
    <div className="relative h-5 w-7">
      <Image
        src={language.flag}
        alt={language.name}
        fill
        className="object-cover rounded"
      />
    </div>
  );
}