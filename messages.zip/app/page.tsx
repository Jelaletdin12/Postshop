import { redirect } from "next/navigation"

export default function RootPage() {
  console.log("[ROOT] Redirecting to /ru")
  redirect("/ru")
}