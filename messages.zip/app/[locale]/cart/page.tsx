"use client";

import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import CartItemCard from "./ui/CartItemCard";
import OrderSummary from "./ui/OrderSummary";
import {
  Order,
  Region,
  PickUpPoint,
  PaymentType,
  DeliveryType,
  CartTranslations,
} from "./ui/types";
import jbl from "@/public/jbl.png";
import jb from "@/public/jb.webp";

interface CartPageProps {
  locale?: string;
  translations?: CartTranslations;
}

// Mock data
const MOCK_ORDERS: Order[] = [
  {
    id: 1,
    seller: { id: 1, name: "Магазин Электроники" },
    items: [
      {
        id: 1,
        product: { id: 101, name: "iPhone 15 Pro Max 256GB", images: [jbl], image: jbl },
        quantity: 2,
        price: 1299,
        price_formatted: "1,299.00 TMT",
        sub_total_formatted: "100.00 TMT",
        discount_formatted: "50.00 TMT",
        total_formatted: "2,548.00 TMT",
      },
      {
        id: 2,
        product: { id: 102, name: "AirPods Pro 2", images: [jb], image: jb },
        quantity: 1,
        price: 249,
        price_formatted: "249.00 TMT",
        sub_total_formatted: "20.00 TMT",
        discount_formatted: "0.00 TMT",
        total_formatted: "269.00 TMT",
      },
    ],
    billing: {
      body: [
        { title: "Товары", value: "2,817.00 TMT" },
        { title: "Доставка", value: "50.00 TMT" },
        { title: "Скидка", value: "-50.00 TMT" },
      ],
      footer: { title: "Итого", value: "2,817.00 TMT" },
    },
  },
  {
    id: 2,
    seller: { id: 2, name: "Магазин Одежды" },
    items: [
      {
        id: 3,
        product: { id: 201, name: "Nike Air Max", images: [jbl], image: jbl },
        quantity: 1,
        price: 189,
        price_formatted: "189.00 TMT",
        sub_total_formatted: "15.00 TMT",
        discount_formatted: "10.00 TMT",
        total_formatted: "194.00 TMT",
      },
    ],
    billing: {
      body: [
        { title: "Товары", value: "194.00 TMT" },
        { title: "Доставка", value: "30.00 TMT" },
      ],
      footer: { title: "Итого", value: "224.00 TMT" },
    },
  },
];

const MOCK_REGIONS: Region[] = [
  { id: 1, name: "Ашхабад" },
  { id: 2, name: "Мары" },
  { id: 3, name: "Туркменабад" },
];

const MOCK_ADDRESSES = [
  "ул. Пушкина, д. 10, кв. 25",
  "пр. Нейтралитета, д. 5",
  "ул. Магтымгулы, д. 15, кв. 8",
];

const MOCK_PICKUP_POINTS: PickUpPoint[] = [
  { id: 1, name: "Пункт выдачи №1", address: "ул. Ленина, 20" },
  { id: 2, name: "Пункт выдачи №2", address: "пр. Независимости, 45" },
];

const DEFAULT_TRANSLATIONS: CartTranslations = {
  cart: "Корзина",
  ordersIn: "Имеется заказ в магазинах:",
  pricePerUnit: "Цена за шт",
  additionalPrice: "Дополнительная цена:",
  discount: "Скидка:",
  totalPrice: "Общая цена:",
  paymentType: "Тип оплаты",
  cash: "Наличные",
  card: "Карта",
  deliveryType: "Тип доставки",
  delivery: "Доставка",
  pickup: "Самовывоз",
  selectRegion: "Выберите регион",
  selectAddress: "Выберите адрес",
  note: "Заметка",
  placeOrder: "Заказать",
  emptyCart: "Ваша корзина пуста",
  map: "Карта",
};

export default function CartPage({ locale = "ru", translations }: CartPageProps) {
  const [isClient, setIsClient] = useState(false);
  const [orders] = useState<Order[]>(MOCK_ORDERS);
  const [selectedMarket, setSelectedMarket] = useState<number>(1);
  const [paymentType, setPaymentType] = useState<PaymentType>("CASH");
  const [deliveryType, setDeliveryType] = useState<DeliveryType>("SELECTED_DELIVERY");
  const [selectedRegion, setSelectedRegion] = useState<number>(1);
  const [selectedAddress, setSelectedAddress] = useState<string>("");
  const [note, setNote] = useState<string>("");
  const [isMapOpen, setIsMapOpen] = useState(false);

  const t = translations || DEFAULT_TRANSLATIONS;

  useEffect(() => {
    setIsClient(true);
  }, []);

  const currentOrder = orders.find((o) => o.id === selectedMarket);

  const handleQuantityChange = (itemId: number, delta: number) => {
    console.log("Update quantity:", itemId, delta);
    // TODO: Implement quantity update logic
  };

  const handleDeleteItem = (itemId: number) => {
    console.log("Delete item:", itemId);
    // TODO: Implement delete logic
  };

  const handleDeliveryTypeChange = (type: DeliveryType) => {
    setDeliveryType(type);
    setSelectedAddress("");
  };

  const handleCompleteOrder = () => {
    if (!selectedAddress) return;
    console.log("Complete order");
    // TODO: Implement order completion logic
  };

  if (!isClient) return null;

  if (!orders.length) {
    return (
      <div className="container mx-auto px-4 min-h-[90vh] flex items-center justify-center">
        <h2 className="text-3xl md:text-4xl lg:text-5xl text-gray-400 font-semibold">
          {t.emptyCart}
        </h2>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 min-h-screen">
      <h1 className="text-3xl font-bold mb-6">{t.cart}</h1>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Cart Items Section */}
        <div className="flex-1">
          <Card className="p-6 rounded-xl">
            {/* Store Selector */}
            <div className="mb-6">
              <p className="text-base mb-3">{t.ordersIn}</p>
              <div className="flex flex-wrap gap-2">
                {orders.map((order) => (
                  <Button
                    key={order.id}
                    variant={selectedMarket === order.id ? "default" : "outline"}
                    onClick={() => setSelectedMarket(order.id)}
                    className="rounded-xl"
                  >
                    {order.seller.name}
                  </Button>
                ))}
              </div>
              <Separator className="mt-4" />
            </div>

            {/* Cart Items */}
            <div className="space-y-4">
              {currentOrder?.items.map((item) => (
                <CartItemCard
                  key={item.id}
                  item={item}
                  translations={t}
                  onQuantityChange={handleQuantityChange}
                  onDelete={handleDeleteItem}
                />
              ))}
            </div>
          </Card>
        </div>

        {/* Order Summary Sidebar */}
        {currentOrder && (
          <OrderSummary
            order={currentOrder}
            translations={t}
            paymentType={paymentType}
            deliveryType={deliveryType}
            selectedRegion={selectedRegion}
            selectedAddress={selectedAddress}
            note={note}
            regions={MOCK_REGIONS}
            addresses={MOCK_ADDRESSES}
            pickupPoints={MOCK_PICKUP_POINTS}
            onPaymentTypeChange={setPaymentType}
            onDeliveryTypeChange={handleDeliveryTypeChange}
            onRegionChange={setSelectedRegion}
            onAddressChange={setSelectedAddress}
            onNoteChange={setNote}
            onMapOpen={() => setIsMapOpen(true)}
            onCompleteOrder={handleCompleteOrder}
          />
        )}
      </div>
    </div>
  );
}