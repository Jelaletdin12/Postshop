"use client";
import { useEffect, useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import Image, { StaticImageData } from "next/image";
import Link from "next/link";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import "swiper/css";
import ProductCard from "@/components/ProductCard";
import { Card, CardContent } from "@/components/ui/card";
import temp1 from "@/public/temp1.jpg";
import temp2 from "@/public/temp2.jpg";
import temp3 from "@/public/temp3.jpg";
import jbl from "@/public/jbl.png";
import jbll from "@/public/jbll.png";
import jbl3 from "@/public/jbl3.webp";
import jb from "@/public/jb.webp";

type CarouselItem = {
  title: string;
  image: StaticImageData | string;
  url?: string | null;
};

type Category = {
  id: number;
  slug: string;
  name: string;
  image: StaticImageData | string;
};

type Product = {
  id: number;
  name: string;
  struct_price_text: string;
  price: number | null;
  images: (StaticImageData | string)[];
  is_favorite: boolean;
  labels?: { text: string; bg_color: string }[];
  price_color?: string;
};

export default function HomePage() {
  const locale = useLocale();
  const t = useTranslations("common");
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const carouselItems: CarouselItem[] = [
    { title: "Banner 1", image: temp1, url: "#" },
    { title: "Banner 2", image: temp2, url: "#" },
    { title: "Banner 3", image: temp3, url: "#" },
  ];

  const categories: Category[] = [
    { id: 1, slug: "sneakers", name: "Sneakers", image: jbl },
    { id: 2, slug: "boots", name: "Boots", image: jbl3 },
    { id: 3, slug: "sandals", name: "Sandals", image: jbll },
    { id: 4, slug: "heels", name: "Heels", image: jb },
  ];

  const products: Product[] = [
    {
      id: 1,
      name: "Nike Air Max 270",
      struct_price_text: "$120",
      price: 120,
      images: [jb, jbll, jbl, jbl3],
      is_favorite: false,
      labels: [{ text: "New", bg_color: "#10B981" }],
    },
    {
      id: 2,
      name: "Adidas Ultraboost",
      struct_price_text: "$150",
      price: 150,
      images: [jbll, jb, jbl, jbl3],
      is_favorite: true,
    },
    {
      id: 3,
      name: "Puma RS-X",
      struct_price_text: "$110",
      price: 110,
      images: [jbl3, jbll, jbl, jb],
      is_favorite: false,
    },
    {
      id: 4,
      name: "New Balance 327",
      struct_price_text: "$130",
      price: 130,
      images: [jbl, jbll, jb, jbl3],
      is_favorite: false,
    },
  ];

  if (!isMounted) return <div className="p-8">Loading...</div>;

  return (
    <div className="px-4 md:px-8 lg:px-12 pt-8 pb-12 space-y-8">
      {/* HERO CAROUSEL */}
      <section className="rounded-2xl overflow-hidden">
        <Swiper
          modules={[Autoplay]}
          slidesPerView={1}
          loop
          autoplay={{ delay: 3000, disableOnInteraction: false }}
        >
          {carouselItems.map((item, i) => (
            <SwiperSlide key={i}>
              <div className="relative w-full h-[200px] sm:h-[300px] md:h-[420px]">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-cover"
                />
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </section>

      {/* CATEGORY SECTION */}
      <section className="bg-white rounded-2xl shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4">{t("categories")}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              href={`/${locale}/category/${cat.slug}?category_id=${cat.id}`}
              className="no-underline"
            >
              <Card className="hover:shadow-md border-none! shadow-none p-0  gap-2  transition-all cursor-pointer text-center">
                <div className="relative w-full h-36  overflow-hidden ">
                  <Image
                    src={cat.image}
                    alt={cat.name}
                    fill
                    className="object-contain l"
                  />
                </div>
                <CardContent className="py-2">
                  <p className="text-sm font-medium text-gray-800 truncate">
                    {cat.name}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* PRODUCT SECTION */}
      <section className="bg-white rounded-2xl shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4">{t("products")}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              struct_price_text={product.struct_price_text}
              images={product.images}
              is_favorite={product.is_favorite}
              labels={product.labels}
              price_color={product.price_color ?? "#111"}
              height={360}
              width={250}
              button={true}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
