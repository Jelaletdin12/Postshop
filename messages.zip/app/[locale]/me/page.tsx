"use client";

import React, { useState, useEffect } from "react";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface User {
  first_name: string;
  last_name: string;
  phone: string;
  email?: string;
}

interface ProfilePageProps {
  locale?: string;
  isAuthenticated?: boolean;
  translations?: {
    profile: string;
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
    logout: string;
    loading: string;
  };
}

export default function ProfilePage({
  locale = "ru",
  isAuthenticated = false,
  translations,
}: ProfilePageProps) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const t = translations || {
    profile: "Профиль",
    firstName: "Имя",
    lastName: "Фамилия",
    phone: "Номер телефона",
    email: "Email",
    logout: "Выйти",
    loading: "Загрузка...",
  };

  useEffect(() => {
    // Redirect if not authenticated
    if (!isAuthenticated) {
      window.location.href = "/";
      return;
    }

    // Simulate fetching user data
    const fetchUserData = () => {
      setTimeout(() => {
        setUser({
          first_name: "Иван",
          last_name: "Иванов",
          phone: "+99361234567",
          email: "ivan@example.com",
        });
        setLoading(false);
      }, 500);
    };

    fetchUserData();
  }, [isAuthenticated]);

  const handleLogout = () => {
    // Clear auth token
    window.location.href = "/";
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <p className="text-lg text-gray-600">{t.loading}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 pt-20">
      <div className="container mx-auto max-w-2xl">
        <h1 className="text-3xl font-bold mb-6">{t.profile}</h1>

        <Card className="shadow-lg mb-4">
          <CardHeader>
            <CardTitle>Личная информация</CardTitle>
            <CardDescription>Ваши данные профиля</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {user && (
              <>
                {/* First Name */}
                <div className="space-y-2">
                  <Label htmlFor="firstName">{t.firstName}</Label>
                  <Input
                    id="firstName"
                    value={user.first_name}
                    disabled
                    className="bg-gray-50"
                  />
                </div>

                {/* Last Name */}
                <div className="space-y-2">
                  <Label htmlFor="lastName">{t.lastName}</Label>
                  <Input
                    id="lastName"
                    value={user.last_name}
                    disabled
                    className="bg-gray-50"
                  />
                </div>

                {/* Phone */}
                <div className="space-y-2">
                  <Label htmlFor="phone">{t.phone}</Label>
                  <Input
                    id="phone"
                    value={user.phone}
                    disabled
                    className="bg-gray-50"
                  />
                </div>

                {/* Email (optional) */}
                {user.email && (
                  <div className="space-y-2">
                    <Label htmlFor="email">{t.email}</Label>
                    <Input
                      id="email"
                      value={user.email}
                      disabled
                      className="bg-gray-50"
                    />
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Logout Button */}
        <Button
          onClick={handleLogout}
          variant="destructive"
          size="lg"
          className="w-full max-w-md flex items-center justify-center gap-2"
        >
          <LogOut className="h-5 w-5" />
          {t.logout}
        </Button>
      </div>
    </div>
  );
}
