"use client";

import React, { useState } from "react";
import Image from "next/image";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

// Types
interface OrderItem {
  product: {
    id: number;
    name: string;
    image: string;
  };
}

interface BillingItem {
  title: string;
  value: string;
}

interface Order {
  id: number;
  status: "PENDING" | "PROCESSING" | "DELIVERED" | "CANCELLED";
  status_trans: string;
  items: OrderItem[];
  billing: {
    body: BillingItem[];
  };
}

interface OrdersData {
  active_orders: Order[];
  complete_orders: Order[];
}

interface OrdersPageProps {
  orders: OrdersData;
  locale?: string;
  translations?: {
    orders: string;
    active: string;
    completed: string;
    cancelOrder: string;
    areYouSure: string;
    yes: string;
    no: string;
    orderNumber: string;
  };
}

export default function OrdersPage({
  orders,
  locale = "ru",
  translations,
}: OrdersPageProps) {
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<"active" | "completed">("active");

  const t = translations || {
    orders: "Заказы",
    active: "Активные",
    completed: "Завершенные",
    cancelOrder: "Отменить заказ",
    areYouSure: "Вы уверены?",
    yes: "Да",
    no: "Нет",
    orderNumber: "№",
  };

  const handleCancelOrder = (orderId: number) => {
    setSelectedOrderId(orderId);
    setIsDeleteModalOpen(true);
  };

  const confirmCancelOrder = async () => {
    if (selectedOrderId) {
      // Implement cancel order logic
      console.log("Canceling order:", selectedOrderId);
      setIsDeleteModalOpen(false);
      setSelectedOrderId(null);
      // Reload or update orders
      window.location.reload();
    }
  };

  const getStatusColor = (order: Order, isActive: boolean) => {
    if (isActive) return "bg-primary text-white";
    if (order.status === "CANCELLED") return "bg-red-500 text-white";
    return "bg-green-500 text-white";
  };

  const renderOrderCard = (order: Order, isActive: boolean) => (
    <Card key={order.id} className="p-4 rounded-xl">
      {/* Order Header */}
      <div className="flex justify-between items-center mb-4 px-2">
        <h3 className="text-lg font-semibold">
          {t.orderNumber} {order.id}
        </h3>
        <Badge className={`${getStatusColor(order, isActive)} px-3 py-1`}>
          {order.status_trans}
        </Badge>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-center">
        {/* Product Images */}
        <div className="flex gap-2 flex-wrap justify-start flex-1">
          {order.items.slice(0, 6).map((item, index) => {
            if (!item.product?.image) return null;
            return (
              <div
                key={`${item.product.id}-${index}`}
                className="relative w-14 h-[76px] rounded-lg border overflow-hidden flex-shrink-0"
              >
                <Image
                  src={item.product.image}
                  alt={item.product.name}
                  fill
                  className="object-contain"
                />
              </div>
            );
          })}
        </div>

        {/* Order Details */}
        <div className="flex-1 grid grid-cols-2 gap-4 w-full sm:w-auto">
          {order.billing.body.map((item) => (
            <div
              key={item.title}
              className="flex flex-col sm:flex-row gap-2 justify-end items-start sm:items-center"
            >
              <span className="text-sm text-gray-500">{item.title}</span>
              <span className="text-sm font-bold">{item.value}</span>
            </div>
          ))}
        </div>

        {/* Cancel Button */}
        {isActive && (
          <div className="flex items-center">
            <Button
              variant="destructive"
              size="lg"
              onClick={() => handleCancelOrder(order.id)}
              className="rounded-xl"
            >
              {t.cancelOrder}
            </Button>
          </div>
        )}
      </div>
    </Card>
  );

  return (
    <div className="container mx-auto px-4 py-8 min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h1 className="text-3xl font-bold">{t.orders}</h1>
      </div>

      {/* Orders Tabs */}
      <Tabs
        value={activeTab}
        onValueChange={(value) => setActiveTab(value as "active" | "completed")}
        className="w-full"
      >
        <TabsList className="grid w-full max-w-md grid-cols-2 mb-6">
          <TabsTrigger value="active" className="rounded-xl">
            {t.active}
          </TabsTrigger>
          <TabsTrigger value="completed" className="rounded-xl">
            {t.completed}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          <div className="flex flex-col items-center gap-4 w-full">
            {orders?.active_orders?.length > 0 ? (
              orders.active_orders.map((order) => renderOrderCard(order, true))
            ) : (
              <div className="text-center py-12">
                <p className="text-xl text-gray-400">Нет активных заказов</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          <div className="flex flex-col items-center gap-4 w-full">
            {orders?.complete_orders?.length > 0 ? (
              orders.complete_orders.map((order) =>
                renderOrderCard(order, false)
              )
            ) : (
              <div className="text-center py-12">
                <p className="text-xl text-gray-400">Нет завершенных заказов</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Cancel Confirmation Dialog */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent className="sm:max-w-md rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-center">{t.areYouSure}</DialogTitle>
          </DialogHeader>
          <DialogFooter className="flex gap-2 sm:justify-center">
            <Button
              variant="outline"
              onClick={() => setIsDeleteModalOpen(false)}
              className="rounded-xl flex-1 bg-green-50 hover:bg-green-100"
            >
              {t.no}
            </Button>
            <Button
              variant="destructive"
              onClick={confirmCancelOrder}
              className="rounded-xl flex-1"
            >
              {t.yes}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
