"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter, useSearchParams } from "next/navigation";
import { ChevronLeft, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";

// Types
interface FilterItem {
  key: string;
  value: number;
  name: string;
  hex?: string;
  image?: string;
  selected?: boolean;
  slug?: string;
  children?: FilterItem[];
}

interface Filter {
  uuid: string;
  title: string;
  type: "TREE" | "SELECTABLE" | "VOLUME" | "TAB" | "COLOR";
  items: FilterItem | FilterItem[];
}

interface ProductFiltersProps {
  filters: Filter[];
  locale?: string;
  translations?: {
    filter: string;
    from: string;
    to: string;
    reset: string;
  };
}

export default function ProductFilters({
  filters = [],
  locale = "ru",
  translations,
}: ProductFiltersProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 99999]);
  const [isOpen, setIsOpen] = useState(false);

  const t = translations || {
    filter: "Фильтр",
    from: "От",
    to: "До",
    reset: "Сбросить",
  };

  const handleFilterChange = (key: string, value: number) => {
    const newParams = new URLSearchParams(searchParams.toString());
    const paramKey = `${key}[]`;
    const currentValues = newParams.getAll(paramKey);

    if (currentValues.includes(String(value))) {
      newParams.delete(paramKey);
      currentValues
        .filter((v) => v !== String(value))
        .forEach((v) => newParams.append(paramKey, v));
    } else {
      newParams.append(paramKey, String(value));
    }

    router.push(`?${newParams.toString()}`);
  };

  const handlePriceChange = (values: number[]) => {
    setPriceRange([values[0], values[1]]);

    const newParams = new URLSearchParams(searchParams.toString());
    newParams.set("price_from", String(values[0]));
    newParams.set("price_to", String(values[1]));

    // Debounce the navigation
    const timeoutId = setTimeout(() => {
      router.push(`?${newParams.toString()}`);
    }, 500);

    return () => clearTimeout(timeoutId);
  };

  const handlePriceInputChange = (type: "from" | "to", value: string) => {
    const numValue = Number(value) || 0;
    const newRange: [number, number] =
      type === "from" ? [numValue, priceRange[1]] : [priceRange[0], numValue];

    setPriceRange(newRange);

    const newParams = new URLSearchParams(searchParams.toString());
    newParams.set(
      type === "from" ? "price_from" : "price_to",
      String(numValue)
    );

    const timeoutId = setTimeout(() => {
      router.push(`?${newParams.toString()}`);
    }, 500);

    return () => clearTimeout(timeoutId);
  };

  const renderFilter = (filter: Filter) => {
    switch (filter.type) {
      case "TREE":
        return (
          <CategoryFilter
            data={filter.items as FilterItem}
            title={filter.title}
          />
        );
      case "SELECTABLE":
        return (
          <BrandFilter
            data={filter.items as FilterItem[]}
            title={filter.title}
            onFilterChange={handleFilterChange}
          />
        );
      case "VOLUME":
        return (
          <PriceFilter
            title={filter.title}
            priceRange={priceRange}
            onPriceChange={handlePriceChange}
            onInputChange={handlePriceInputChange}
            translations={t}
          />
        );
      case "TAB":
        return (
          <TagFilter
            data={filter.items as FilterItem[]}
            title={filter.title}
            onFilterChange={handleFilterChange}
          />
        );
      case "COLOR":
        return (
          <ColorFilter
            data={filter.items as FilterItem[]}
            title={filter.title}
            onFilterChange={handleFilterChange}
          />
        );
      default:
        return null;
    }
  };

  const FiltersContent = () => (
    <div className="space-y-6">
      {filters.map((filter) => (
        <div key={filter.uuid}>{renderFilter(filter)}</div>
      ))}
    </div>
  );

  return (
    <>
      {/* Mobile Filter Button */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button className="sm:hidden rounded-xl font-bold gap-2" size="lg">
            {t.filter}
            <SlidersHorizontal className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[290px] p-0">
          <SheetHeader className="p-4 border-b">
            <SheetTitle>{t.filter}</SheetTitle>
          </SheetHeader>
          <ScrollArea className="h-[calc(100vh-80px)] p-4">
            <FiltersContent />
          </ScrollArea>
        </SheetContent>
      </Sheet>

      {/* Desktop Filters */}
      <div className="hidden sm:block w-[280px] flex-shrink-0 border-r pr-4">
        <ScrollArea className="h-[calc(100vh-120px)]">
          <FiltersContent />
        </ScrollArea>
      </div>
    </>
  );
}

// Category Filter Component
function CategoryFilter({ data, title }: { data: FilterItem; title: string }) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="space-y-1">
        <Link
          href={`/category/${data.slug}?category_id=${data.value}`}
          className={`flex items-center gap-2 py-2 px-2 rounded-lg hover:bg-gray-100 transition-colors ${
            data.selected ? "text-primary font-medium" : ""
          }`}
        >
          <ChevronLeft className="h-4 w-4" />
          {data.name}
        </Link>
        {data.children && data.children.length > 0 && (
          <div className="ml-6 space-y-1">
            {data.children.map((child) => (
              <Link
                key={child.value}
                href={`/category/${child.slug}?category_id=${child.value}`}
                className={`block py-2 px-2 rounded-lg hover:bg-gray-100 transition-colors ${
                  child.selected ? "text-primary font-medium" : ""
                }`}
              >
                {child.name}
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Brand Filter Component
function BrandFilter({
  data,
  title,
  onFilterChange,
}: {
  data: FilterItem[];
  title: string;
  onFilterChange: (key: string, value: number) => void;
}) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <ScrollArea className="max-h-[410px]">
        <div className="space-y-1">
          {data.map((item) => (
            <button
              key={item.value}
              onClick={() => onFilterChange(item.key, item.value)}
              className={`w-full flex items-center gap-3 py-2 px-2 rounded-lg hover:bg-gray-100 transition-colors group ${
                item.selected ? "text-primary" : ""
              }`}
            >
              {item.image && (
                <div
                  className={`flex items-center justify-center w-[50px] h-[50px] bg-gray-50 rounded-lg border-2 transition-colors ${
                    item.selected
                      ? "border-primary"
                      : "border-transparent group-hover:border-primary"
                  }`}
                >
                  <div className="relative w-8 h-8">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      className="object-contain"
                    />
                  </div>
                </div>
              )}
              <span className="text-left">{item.name}</span>
            </button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}

// Price Filter Component
function PriceFilter({
  title,
  priceRange,
  onPriceChange,
  onInputChange,
  translations,
}: {
  title: string;
  priceRange: [number, number];
  onPriceChange: (values: number[]) => void;
  onInputChange: (type: "from" | "to", value: string) => void;
  translations: { from: string; to: string };
}) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="space-y-4">
        <div className="flex gap-2">
          <div className="flex-1">
            <Label htmlFor="price-from" className="text-xs mb-1">
              {translations.from}
            </Label>
            <Input
              id="price-from"
              type="number"
              value={priceRange[0]}
              onChange={(e) => onInputChange("from", e.target.value)}
              className="rounded-lg"
            />
          </div>
          <div className="flex-1">
            <Label htmlFor="price-to" className="text-xs mb-1">
              {translations.to}
            </Label>
            <Input
              id="price-to"
              type="number"
              value={priceRange[1]}
              onChange={(e) => onInputChange("to", e.target.value)}
              className="rounded-lg"
            />
          </div>
        </div>
        <Slider
          min={0}
          max={99999}
          step={100}
          value={priceRange}
          onValueChange={onPriceChange}
          className="mt-2"
        />
      </div>
    </div>
  );
}

// Tag Filter Component
function TagFilter({
  data,
  title,
  onFilterChange,
}: {
  data: FilterItem[];
  title: string;
  onFilterChange: (key: string, value: number) => void;
}) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="space-y-2">
        {data.map((item) => (
          <div key={item.value} className="flex items-center space-x-2">
            <Checkbox
              id={`tag-${item.value}`}
              checked={item.selected}
              onCheckedChange={() => onFilterChange(item.key, item.value)}
            />
            <Label
              htmlFor={`tag-${item.value}`}
              className="text-sm font-normal cursor-pointer"
            >
              {item.name}
            </Label>
          </div>
        ))}
      </div>
    </div>
  );
}

// Color Filter Component
function ColorFilter({
  data,
  title,
  onFilterChange,
}: {
  data: FilterItem[];
  title: string;
  onFilterChange: (key: string, value: number) => void;
}) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="grid grid-cols-5 gap-2">
        {data.map((item) => (
          <button
            key={item.value}
            onClick={() => onFilterChange(item.key, item.value)}
            className={`w-[36px] h-[36px] rounded-lg border-2 p-1 transition-all hover:scale-110 ${
              item.selected ? "border-primary shadow-md" : "border-gray-200"
            }`}
            title={item.name}
          >
            <div
              className="w-full h-full rounded-md border-2 border-gray-200"
              style={{ backgroundColor: item.hex }}
            />
          </button>
        ))}
      </div>
    </div>
  );
}
