import { getRequestConfig } from "next-intl/server"
import { notFound } from "next/navigation"

export const locales = ["ru", "tm"] as const
export const defaultLocale = "ru" as const

export default getRequestConfig(async ({ requestLocale }) => {
  // Get locale from request - this is the correct parameter for Next.js 15+
  let locale = await requestLocale
  
  console.log("[i18n.ts] getRequestConfig called")
  console.log("[i18n.ts] requestLocale:", locale)
  
  // Fallback to default if undefined
  if (!locale) {
    console.log("[i18n.ts] No locale from request, using default:", defaultLocale)
    locale = defaultLocale
  }
  
  // Validate locale
  if (!locales.includes(locale as any)) {
    console.error("[i18n.ts] Invalid locale:", locale)
    notFound()
  }

  console.log("[i18n.ts] Loading messages for locale:", locale)

  try {
    const messages = (await import(`./messages/${locale}.json`)).default
    console.log("[i18n.ts] Messages loaded successfully")
    return {
      locale,
      messages,
    }
  } catch (error) {
    console.error("[i18n.ts] Failed to load messages:", error)
    return {
      locale,
      messages: {},
    }
  }
})